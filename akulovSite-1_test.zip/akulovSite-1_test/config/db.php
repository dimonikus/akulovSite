<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=shark',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
