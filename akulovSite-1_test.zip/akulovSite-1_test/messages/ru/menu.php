<?php

return [
    'Home' => 'Главная',
    'About' => 'О нас',
    'Contact' => 'Контакты',
    'Login' => 'Вход',
    'Logout' => 'Выход',
];