<?php

return [
    'Home' => 'Головна',
];